package net.Sanix.Fabric.Mod.items;

import net.Sanix.Fabric.Mod.SanixFM;
import net.minecraft.item.ElytraItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class BlackDiamondElytra extends ElytraItem {

	public BlackDiamondElytra() {
		super(new Item.Settings().group(SanixFM.ARMOR));
	}
	
	@Override
	public boolean canRepair(ItemStack stack, ItemStack ingredient) {
	      return ingredient.getItem() == SanixFM.BLACK_DIAMOND;
	 }
	
}
