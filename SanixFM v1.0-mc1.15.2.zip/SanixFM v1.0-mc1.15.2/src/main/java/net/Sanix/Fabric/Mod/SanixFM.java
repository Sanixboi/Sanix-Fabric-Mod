package net.Sanix.Fabric.Mod;


import net.Sanix.Fabric.Mod.ArmorMaterial.BlackDiamondArmorMaterial;
import net.Sanix.Fabric.Mod.ArmorMaterial.EmeraldReinforcedDiamondArmorMaterial;
import net.Sanix.Fabric.Mod.ArmorMaterial.EnderpearlReinforcedDiamondArmorMaterial;
import net.Sanix.Fabric.Mod.ArmorMaterial.ModdedArmorMaterials;
import net.Sanix.Fabric.Mod.ArmorMaterial.ReinforcedDiamondArmorMaterial;
import net.Sanix.Fabric.Mod.Toolbase.AxeBase;
import net.Sanix.Fabric.Mod.Toolbase.BowBase;
import net.Sanix.Fabric.Mod.Toolbase.HoeBase;
import net.Sanix.Fabric.Mod.Toolbase.PickaxeBase;
import net.Sanix.Fabric.Mod.Toolbase.ShovelBase;
import net.Sanix.Fabric.Mod.Toolbase.SwordBase;
import net.Sanix.Fabric.Mod.blocks.BlackDiamondBlock;
import net.Sanix.Fabric.Mod.blocks.BlueDyeBlock;
import net.Sanix.Fabric.Mod.blocks.CompressedEndStone;
import net.Sanix.Fabric.Mod.blocks.EmeraldReinforcedDiamondBlock;
import net.Sanix.Fabric.Mod.blocks.EnderPearlReinforcedDiamondBlock;
import net.Sanix.Fabric.Mod.blocks.ReinforcedDiamondBlock;
import net.Sanix.Fabric.Mod.blocks.SanixBlock;
import net.Sanix.Fabric.Mod.blocks.SkyDiamondBlock;
import net.Sanix.Fabric.Mod.blocks.SkyDiamondOre;
import net.Sanix.Fabric.Mod.fluids.LimeWater;
import net.Sanix.Fabric.Mod.inventories.SkyDiamondHelmetController;
import net.Sanix.Fabric.Mod.items.BlackDiamondElytra;
import net.Sanix.Fabric.Mod.items.SkyDiamondHelmet;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialAcacia;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialAndesite;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialBirch;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialBlackDiamond;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialDarkOak;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialDiorite;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialEmeraldReinforcedDiamond;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialEnderpearlReinforcedDiamond;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialGranite;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialJungle;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialOak;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialReinforcedDiamond;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialSkyDiamond;
import net.Sanix.Fabric.Mod.toolmaterial.ToolMaterialSpruce;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.block.FabricBlockSettings;
import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;
import net.fabricmc.fabric.api.container.ContainerProviderRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.fluid.BaseFluid;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BucketItem;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ToolMaterial;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
/*
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.DefaultBiomeFeatures;
import net.minecraft.world.biome.Biomes;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.decorator.Decorator;
import net.minecraft.world.gen.decorator.RangeDecoratorConfig;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.FeatureConfig;
import net.minecraft.world.gen.feature.OreFeatureConfig;
//*/
public class SanixFM implements ModInitializer {

	/*
	private void handleBiome(Biome biome) {
		if(biome.getCategory() != Biome.Category.NETHER && biome.getCategory() != Biome.Category.THEEND) {
			biome.addFeature(
	        	    GenerationStep.Feature.UNDERGROUND_ORES,
	        	    Biome.configureFeature(
	        	        Feature.ORE,
	        		new OreFeatureConfig(
	        			OreFeatureConfig.Target.NATURAL_STONE,
	        			Blocks.NETHER_QUARTZ_ORE.getDefaultState(),
	        		        8 //Ore vein size
	        		),
	        	        Decorator.COUNT_RANGE,
	        		new RangeDecoratorConfig(
	        			8, //Number of veins per chunk
	        			0, //Bottom Offset
	        			0, //Min y level
	        			64 //Max y level
	        		)));
		}
	}
	*/
	public static String MODID = "sanixfm";
	
	//fluids
	public static Block LIME_WATER;
	public static BaseFluid LIME_WATER_STILL;
	public static BaseFluid LIME_WATER_FLOWING;
	
	//buckets
	public static Item LIME_WATER_BUCKET;
	
	
	//armor
	public static final ArmorMaterial BLACK_DIAMOND_ARMOR = new BlackDiamondArmorMaterial();
	public static final ArmorMaterial REINFORCED_DIAMOND_ARMOR = new ReinforcedDiamondArmorMaterial();
	public static final ArmorMaterial EMERALD_REINFORCED_DIAMOND_ARMOR = new EmeraldReinforcedDiamondArmorMaterial();
	public static final ArmorMaterial ENDER_PEARL_REINFORCED_DIAMOND_ARMOR = new EnderpearlReinforcedDiamondArmorMaterial();
	
	//blocks
	public static final Block SANIX_BLOCK = new SanixBlock();
	public static final Block BLUE_DYE_BLOCK = new BlueDyeBlock();	
	public static final Block BLACK_DIAMOND_BLOCK = new BlackDiamondBlock();
	public static final Block REINFORCED_DIAMOND_BLOCK = new ReinforcedDiamondBlock();
	public static final Block EMERALD_REINFORCED_DIAMOND_BLOCK = new EmeraldReinforcedDiamondBlock();
	public static final Block ENDER_PEARL_REINFORCED_DIAMOND_BLOCK = new EnderPearlReinforcedDiamondBlock();
	public static final Block SKY_DIAMOND_ORE = new SkyDiamondOre();
	public static final Block COMPRESSED_END_STONE = new CompressedEndStone();
	public static final Block SKY_DIAMOND_BLOCK = new SkyDiamondBlock();
	
	//Itemgroup
	public static final ItemGroup BLOCKS = FabricItemGroupBuilder.build(new Identifier(MODID, "blocks"), () -> new ItemStack(SANIX_BLOCK));
	public static final ItemGroup ITEMS = FabricItemGroupBuilder.build(new Identifier(MODID, "items"), () -> new ItemStack(LIME_WATER_BUCKET));
	public static final ItemGroup TOOLS = FabricItemGroupBuilder.build(new Identifier(MODID, "tools"), () -> new ItemStack(BLACK_DIAMOND_BLOCK));
	public static final ItemGroup ARMOR = FabricItemGroupBuilder.build(new Identifier(MODID, "armor"), () -> new ItemStack(BLACK_DIAMOND_BLOCK));
	
	//tools for custom stuff
	public static final Item SKY_DIAMOND_SWORD = new SwordBase(new ToolMaterialSkyDiamond(), 11, 30.6f);
	public static final Item SKY_DIAMOND_PICKAXE = new PickaxeBase(new ToolMaterialSkyDiamond(), 6, -2.2f);
	public static final Item SKY_DIAMOND_AXE = new AxeBase(new ToolMaterialSkyDiamond(), 14, -1.8f);
	public static final Item SKY_DIAMOND_SHOVEL = new ShovelBase(new ToolMaterialSkyDiamond(), 3, -2.2f);
	
	//armor items
	public static final Item SKY_DIAMOND_HELMET = new SkyDiamondHelmet();
	public static final Item SKY_DIAMOND_CHESTPLATE = new ArmorItem(ModdedArmorMaterials.SKY_DIAMOND, EquipmentSlot.CHEST, new Item.Settings().group(SanixFM.ARMOR));
	public static final Item SKY_DIAMOND_LEGGINGS = new ArmorItem(ModdedArmorMaterials.SKY_DIAMOND, EquipmentSlot.LEGS, new Item.Settings().group(SanixFM.ARMOR));
	public static final Item SKY_DIAMOND_BOOTS = new ArmorItem(ModdedArmorMaterials.SKY_DIAMOND, EquipmentSlot.FEET, new Item.Settings().group(SanixFM.ARMOR));
	
	//items
	public static final Item BLACK_DIAMOND = new Item(new Item.Settings().group(SanixFM.ITEMS));
	public static final Item SKY_DIAMOND = new Item(new Item.Settings().group(SanixFM.ITEMS));
	public static final Item DIAMOND_TOOL_ROD = new Item(new Item.Settings().group(SanixFM.ITEMS));
	public static final Item BROWN_DIAMOND_TOOL_ROD = new Item(new Item.Settings().group(SanixFM.ITEMS));
	public static final Item REINFORCED_DIAMOND = new Item(new Item.Settings().group(SanixFM.ITEMS));
	public static final Item EMERALD_REINFORCED_DIAMOND = new Item(new Item.Settings().group(SanixFM.ITEMS));
	public static final Item ENDER_PEARL_REINFORCED_DIAMOND = new Item(new Item.Settings().group(SanixFM.ITEMS));
	public static final Item BLACK_DIAMOND_ELYTRA = new BlackDiamondElytra();
	public static final Item SKY_DIAMOND_APPLE = new Item(new Item.Settings().group(SanixFM.ITEMS).maxCount(99).food(new FoodComponent.Builder().hunger(8).saturationModifier(10.6f).alwaysEdible().statusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 20 * 300, 4), 1f).statusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 20 * 300, 5), 1f).statusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 20 * 600), 1f).statusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 20 * 600, 3), 1f).build()));
	
	
	@Override
	public void onInitialize() {
		/*
		Registry.BIOME.forEach(this::handleBiome);

		RegistryEntryAddedCallback.event(Registry.BIOME).register((i, identifier, biome) -> handleBiome(biome));
		*/
		
		//fluids
	    LIME_WATER_STILL = Registry.FLUID.add(new Identifier(MODID, "lime_water"), new LimeWater.Still());
	    LIME_WATER_FLOWING = Registry.FLUID.add(new Identifier(MODID, "lime_water_flowing"), new LimeWater.Flowing());
	    LIME_WATER = Registry.BLOCK.add(new Identifier(MODID, "lime_water"), new FluidBlock(LIME_WATER_STILL, FabricBlockSettings.copy(Blocks.WATER).build()){});
	    	
	    //buckets
	    LIME_WATER_BUCKET = Registry.ITEM.add(new Identifier(MODID, "lime_water_bucket"), new BucketItem(LIME_WATER_STILL, new Item.Settings().recipeRemainder(Items.BUCKET).maxCount(1).group(SanixFM.ITEMS)));
		
		//armor
	    Registry.register(Registry.ITEM, new Identifier(MODID, "black_diamond_helmet"), new ArmorBase(BLACK_DIAMOND_ARMOR, EquipmentSlot.HEAD));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "black_diamond_chestplate"), new ArmorBase(BLACK_DIAMOND_ARMOR, EquipmentSlot.CHEST));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "black_diamond_leggings"), new ArmorBase(BLACK_DIAMOND_ARMOR, EquipmentSlot.LEGS));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "black_diamond_boots"), new ArmorBase(BLACK_DIAMOND_ARMOR, EquipmentSlot.FEET));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "reinforced_diamond_helmet"), new ArmorBase(REINFORCED_DIAMOND_ARMOR, EquipmentSlot.HEAD));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "reinforced_diamond_chestplate"), new ArmorBase(REINFORCED_DIAMOND_ARMOR, EquipmentSlot.CHEST));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "reinforced_diamond_leggings"), new ArmorBase(REINFORCED_DIAMOND_ARMOR, EquipmentSlot.LEGS));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "reinforced_diamond_boots"), new ArmorBase(REINFORCED_DIAMOND_ARMOR, EquipmentSlot.FEET));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "emerald_reinforced_diamond_helmet"), new ArmorBase(EMERALD_REINFORCED_DIAMOND_ARMOR, EquipmentSlot.HEAD));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "emerald_reinforced_diamond_chestplate"), new ArmorBase(EMERALD_REINFORCED_DIAMOND_ARMOR, EquipmentSlot.CHEST));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "emerald_reinforced_diamond_leggings"), new ArmorBase(EMERALD_REINFORCED_DIAMOND_ARMOR, EquipmentSlot.LEGS));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "emerald_reinforced_diamond_boots"), new ArmorBase(EMERALD_REINFORCED_DIAMOND_ARMOR, EquipmentSlot.FEET));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "ender_pearl_reinforced_diamond_helmet"), new ArmorBase(ENDER_PEARL_REINFORCED_DIAMOND_ARMOR, EquipmentSlot.HEAD));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "ender_pearl_reinforced_diamond_chestplate"), new ArmorBase(ENDER_PEARL_REINFORCED_DIAMOND_ARMOR, EquipmentSlot.CHEST));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "ender_pearl_reinforced_diamond_leggings"), new ArmorBase(ENDER_PEARL_REINFORCED_DIAMOND_ARMOR, EquipmentSlot.LEGS));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "ender_pearl_reinforced_diamond_boots"), new ArmorBase(ENDER_PEARL_REINFORCED_DIAMOND_ARMOR, EquipmentSlot.FEET));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "sky_diamond_helmet"), SKY_DIAMOND_HELMET);
		ContainerProviderRegistry.INSTANCE.registerFactory(SkyDiamondHelmet.ID, (syncId, id, player, buf) -> new SkyDiamondHelmetController(syncId, player.inventory));
	    Registry.register(Registry.ITEM, new Identifier(MODID, "sky_diamond_chestplate"), SKY_DIAMOND_CHESTPLATE);
	    Registry.register(Registry.ITEM, new Identifier(MODID, "sky_diamond_leggings"), SKY_DIAMOND_LEGGINGS);
	    Registry.register(Registry.ITEM, new Identifier(MODID, "sky_diamond_boots"), SKY_DIAMOND_BOOTS);
	    
		//dimensions
	    
	    //black diamond tools 
		Registry.register(Registry.ITEM, new Identifier(MODID, "black_diamond_sword"), new SwordBase(new ToolMaterialBlackDiamond(), 4, 23.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "black_diamond_pickaxe"), new PickaxeBase(new ToolMaterialBlackDiamond(), 2, -2.5f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "black_diamond_axe"), new AxeBase(new ToolMaterialBlackDiamond(), 7, -2.8f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "black_diamond_shovel"), new ShovelBase(new ToolMaterialBlackDiamond(), 2, -2.7f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "black_diamond_hoe"), new HoeBase(new ToolMaterialBlackDiamond(), 0f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "black_diamond_bow"), new BowBase());
		
		//reinforced diamond tools
		Registry.register(Registry.ITEM, new Identifier(MODID, "reinforced_diamond_sword"), new SwordBase(new ToolMaterialReinforcedDiamond(), 6, 25.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "reinforced_diamond_pickaxe"), new PickaxeBase(new ToolMaterialReinforcedDiamond(), 3, -2.4f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "reinforced_diamond_axe"), new AxeBase(new ToolMaterialReinforcedDiamond(), 9, -2.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "reinforced_diamond_shovel"), new ShovelBase(new ToolMaterialReinforcedDiamond(), 3, -2.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "reinforced_diamond_hoe"), new HoeBase(new ToolMaterialReinforcedDiamond(), 0.2f));
		
		//emerald reinforced diamond tools
		Registry.register(Registry.ITEM, new Identifier(MODID, "emerald_reinforced_diamond_sword"), new SwordBase(new ToolMaterialEmeraldReinforcedDiamond(), 7, 26.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "emerald_reinforced_diamond_pickaxe"), new PickaxeBase(new ToolMaterialEmeraldReinforcedDiamond(), 4, -2.3f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "emerald_reinforced_diamond_axe"), new AxeBase(new ToolMaterialEmeraldReinforcedDiamond(), 10, -2.4f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "emerald_reinforced_diamond_shovel"), new ShovelBase(new ToolMaterialEmeraldReinforcedDiamond(), 4, -2.5f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "emerald_reinforced_diamond_hoe"), new HoeBase(new ToolMaterialEmeraldReinforcedDiamond(), 0.4f));
		
		//ender pearl reinforced diamond tools
		Registry.register(Registry.ITEM, new Identifier(MODID, "ender_pearl_reinforced_diamond_sword"), new SwordBase(new ToolMaterialEnderpearlReinforcedDiamond(), 9, 28.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "ender_pearl_reinforced_diamond_pickaxe"), new PickaxeBase(new ToolMaterialEnderpearlReinforcedDiamond(), 6, -2.2f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "ender_pearl_reinforced_diamond_axe"), new AxeBase(new ToolMaterialEnderpearlReinforcedDiamond(), 13, -1.8f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "ender_pearl_reinforced_diamond_shovel"), new ShovelBase(new ToolMaterialEnderpearlReinforcedDiamond(), 5, -2.4f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "ender_pearl_reinforced_diamond_hoe"), new HoeBase(new ToolMaterialEnderpearlReinforcedDiamond(), 1f));
		
		//sky diamond tools
		Registry.register(Registry.ITEM, new Identifier(MODID, "sky_diamond_sword"), SKY_DIAMOND_SWORD);
		Registry.register(Registry.ITEM, new Identifier(MODID, "sky_diamond_pickaxe"), SKY_DIAMOND_PICKAXE);
		Registry.register(Registry.ITEM, new Identifier(MODID, "sky_diamond_axe"), SKY_DIAMOND_AXE);
		Registry.register(Registry.ITEM, new Identifier(MODID, "sky_diamond_shovel"), SKY_DIAMOND_SHOVEL);
		
		//oak tools
		
		Registry.register(Registry.ITEM, new Identifier(MODID, "oak_sword"), new SwordBase(new ToolMaterialOak(), 1, 21.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "oak_pickaxe"), new PickaxeBase(new ToolMaterialOak(), 1, -2.8f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "oak_axe"), new AxeBase(new ToolMaterialOak(), 6, -3.2f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "oak_shovel"), new ShovelBase(new ToolMaterialOak(), 1, -3f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "oak_hoe"), new HoeBase(new ToolMaterialOak(), 1f));
		
		
		//spruce tools
		Registry.register(Registry.ITEM, new Identifier(MODID, "spruce_sword"), new SwordBase(new ToolMaterialSpruce(), 1, 21.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "spruce_pickaxe"), new PickaxeBase(new ToolMaterialSpruce(), 1, -2.8f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "spruce_axe"), new AxeBase(new ToolMaterialSpruce(), 6, -3.2f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "spruce_shovel"), new ShovelBase(new ToolMaterialSpruce(), 1, -3f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "spruce_hoe"), new HoeBase(new ToolMaterialSpruce(), 1f));
		
		//birch tools
		Registry.register(Registry.ITEM, new Identifier(MODID, "birch_sword"), new SwordBase(new ToolMaterialBirch(), 1, 21.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "birch_pickaxe"), new PickaxeBase(new ToolMaterialBirch(), 1, -2.8f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "birch_axe"), new AxeBase(new ToolMaterialBirch(), 6, -3.2f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "birch_shovel"), new ShovelBase(new ToolMaterialBirch(), 1, -3f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "birch_hoe"), new HoeBase(new ToolMaterialBirch(), 1f));
		
		//jungle tools
		Registry.register(Registry.ITEM, new Identifier(MODID, "jungle_sword"), new SwordBase(new ToolMaterialJungle(), 1, 21.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "jungle_pickaxe"), new PickaxeBase(new ToolMaterialJungle(), 1, -2.8f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "jungle_axe"), new AxeBase(new ToolMaterialJungle(), 6, -3.2f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "jungle_shovel"), new ShovelBase(new ToolMaterialJungle(), 1, -3f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "jungle_hoe"), new HoeBase(new ToolMaterialJungle(), 1f));
		
		//dark oak tools
		Registry.register(Registry.ITEM, new Identifier(MODID, "dark_oak_sword"), new SwordBase(new ToolMaterialDarkOak(), 1, 21.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "dark_oak_pickaxe"), new PickaxeBase(new ToolMaterialDarkOak(), 1, -2.8f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "dark_oak_axe"), new AxeBase(new ToolMaterialDarkOak(), 6, -3.2f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "dark_oak_shovel"), new ShovelBase(new ToolMaterialDarkOak(), 1, -3f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "dark_oak_hoe"), new HoeBase(new ToolMaterialDarkOak(), 1f));
		
		//acacia tools
		Registry.register(Registry.ITEM, new Identifier(MODID, "acacia_sword"), new SwordBase(new ToolMaterialAcacia(), 1, 21.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "acacia_pickaxe"), new PickaxeBase(new ToolMaterialAcacia(), 1, -2.8f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "acacia_axe"), new AxeBase(new ToolMaterialAcacia(), 6, -3.2f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "acacia_shovel"), new ShovelBase(new ToolMaterialAcacia(), 1, -3f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "acacia_hoe"), new HoeBase(new ToolMaterialAcacia(), 1f));
		
		//andesite tools
		Registry.register(Registry.ITEM, new Identifier(MODID, "andesite_sword"), new SwordBase(new ToolMaterialAndesite(), 1, 21.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "andesite_pickaxe"), new PickaxeBase(new ToolMaterialAndesite(), 1, -2.8f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "andesite_axe"), new AxeBase(new ToolMaterialAndesite(), 7, -3.2f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "andesite_shovel"), new ShovelBase(new ToolMaterialAndesite(), 1, -3f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "andesite_hoe"), new HoeBase(new ToolMaterialAndesite(), 1f));
		
		//granite tools
		Registry.register(Registry.ITEM, new Identifier(MODID, "granite_sword"), new SwordBase(new ToolMaterialGranite(), 1, 21.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "granite_pickaxe"), new PickaxeBase(new ToolMaterialGranite(), 1, -2.8f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "granite_axe"), new AxeBase(new ToolMaterialGranite(), 7, -3.2f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "granite_shovel"), new ShovelBase(new ToolMaterialGranite(), 1, -3f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "granite_hoe"), new HoeBase(new ToolMaterialGranite(), 1f));
		
		//diorite tools
		Registry.register(Registry.ITEM, new Identifier(MODID, "diorite_sword"), new SwordBase(new ToolMaterialDiorite(), 1, 21.6f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "diorite_pickaxe"), new PickaxeBase(new ToolMaterialDiorite(), 1, -2.8f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "diorite_axe"), new AxeBase(new ToolMaterialDiorite(), 7, -3.2f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "diorite_shovel"), new ShovelBase(new ToolMaterialDiorite(), 1, -3f));
		Registry.register(Registry.ITEM, new Identifier(MODID, "diorite_hoe"), new HoeBase(new ToolMaterialDiorite(), 1f));
		
		//items
		Registry.register(Registry.ITEM, new Identifier(MODID, "black_diamond"), BLACK_DIAMOND);
		Registry.register(Registry.ITEM, new Identifier(MODID, "sky_diamond"), SKY_DIAMOND);
		Registry.register(Registry.ITEM, new Identifier(MODID, "diamond_tool_rod"), DIAMOND_TOOL_ROD);
		Registry.register(Registry.ITEM, new Identifier(MODID, "brown_diamond_tool_rod"), BROWN_DIAMOND_TOOL_ROD);
		Registry.register(Registry.ITEM, new Identifier(MODID, "reinforced_diamond"), REINFORCED_DIAMOND);
		Registry.register(Registry.ITEM, new Identifier(MODID, "emerald_reinforced_diamond"), EMERALD_REINFORCED_DIAMOND);
		Registry.register(Registry.ITEM, new Identifier(MODID, "ender_pearl_reinforced_diamond"), ENDER_PEARL_REINFORCED_DIAMOND);
		Registry.register(Registry.ITEM, new Identifier(MODID, "sky_diamond_apple"), SKY_DIAMOND_APPLE);

	    //Registry.register(Registry.ITEM, new Identifier(MODID, "black_diamond_elytra"), new ElytraItem(new Item.Settings().group(ARMOR)));
		
		//blocks
		Registry.register(Registry.BLOCK, new Identifier(MODID, "sanix_block"), SANIX_BLOCK);
		Registry.register(Registry.BLOCK, new Identifier(MODID, "blue_dye_block"), BLUE_DYE_BLOCK);
		Registry.register(Registry.BLOCK, new Identifier(MODID, "black_diamond_block"), BLACK_DIAMOND_BLOCK);
		Registry.register(Registry.BLOCK, new Identifier(MODID, "reinforced_diamond_block"), REINFORCED_DIAMOND_BLOCK);
		Registry.register(Registry.BLOCK, new Identifier(MODID, "emerald_reinforced_diamond_block"), EMERALD_REINFORCED_DIAMOND_BLOCK);
		Registry.register(Registry.BLOCK, new Identifier(MODID, "ender_pearl_reinforced_diamond_block"), ENDER_PEARL_REINFORCED_DIAMOND_BLOCK);
		Registry.register(Registry.BLOCK, new Identifier(MODID, "sky_diamond_ore"), SKY_DIAMOND_ORE);
		Registry.register(Registry.BLOCK, new Identifier(MODID, "compressed_end_stone"), COMPRESSED_END_STONE);
		Registry.register(Registry.BLOCK, new Identifier(MODID, "sky_diamond_block"), SKY_DIAMOND_BLOCK);
		
		//blockitems
		Registry.register(Registry.ITEM, new Identifier(MODID, "sanix_block"), new BlockItem(SANIX_BLOCK, new Item.Settings().group(SanixFM.BLOCKS)));
		Registry.register(Registry.ITEM, new Identifier(MODID, "blue_dye_block"), new BlockItem(BLUE_DYE_BLOCK, new Item.Settings().group(SanixFM.BLOCKS)));
		Registry.register(Registry.ITEM, new Identifier(MODID, "black_diamond_block"), new BlockItem(BLACK_DIAMOND_BLOCK, new Item.Settings().group(SanixFM.BLOCKS)));
		Registry.register(Registry.ITEM, new Identifier(MODID, "reinforced_diamond_block"), new BlockItem(REINFORCED_DIAMOND_BLOCK, new Item.Settings().group(SanixFM.BLOCKS)));
		Registry.register(Registry.ITEM, new Identifier(MODID, "emerald_reinforced_diamond_block"), new BlockItem(EMERALD_REINFORCED_DIAMOND_BLOCK, new Item.Settings().group(SanixFM.BLOCKS)));
		Registry.register(Registry.ITEM, new Identifier(MODID, "ender_pearl_reinforced_diamond_block"), new BlockItem(ENDER_PEARL_REINFORCED_DIAMOND_BLOCK, new Item.Settings().group(SanixFM.BLOCKS)));
		Registry.register(Registry.ITEM, new Identifier(MODID, "sky_diamond_ore"), new BlockItem(SKY_DIAMOND_ORE, new Item.Settings().group(SanixFM.BLOCKS)));
		Registry.register(Registry.ITEM, new Identifier(MODID, "compressed_end_stone"), new BlockItem(COMPRESSED_END_STONE, new Item.Settings().group(SanixFM.BLOCKS)));
		Registry.register(Registry.ITEM, new Identifier(MODID, "sky_diamond_block"), new BlockItem(SKY_DIAMOND_BLOCK, new Item.Settings().group(SanixFM.BLOCKS)));

	}
	
	
}