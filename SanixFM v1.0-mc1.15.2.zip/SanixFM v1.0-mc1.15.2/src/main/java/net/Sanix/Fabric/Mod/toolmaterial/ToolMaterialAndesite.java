package net.Sanix.Fabric.Mod.toolmaterial;

import net.minecraft.block.Blocks;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class ToolMaterialAndesite implements ToolMaterial{

	@Override
	public int getDurability() {
		return 140;
	}

	@Override
	public float getMiningSpeed() {
		return 4;
	}

	@Override
	public float getAttackDamage() {
		return 1.0f;
	}

	@Override
	public int getMiningLevel() {
		return 1;
	}

	@Override
	public int getEnchantability() {
		return 5;
	}

	@Override
	public Ingredient getRepairIngredient() {
		return Ingredient.ofItems(Blocks.ANDESITE);
	}

}
