package net.Sanix.Fabric.Mod;

import java.util.function.Function;

import net.Sanix.Fabric.Mod.guis.SkyDiamondHelmetScreen;
import net.Sanix.Fabric.Mod.inventories.SkyDiamondHelmetController;
import net.Sanix.Fabric.Mod.items.SkyDiamondHelmet;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.screen.ScreenProviderRegistry;
import net.fabricmc.fabric.api.event.client.ClientSpriteRegistryCallback;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.fluid.BaseFluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.BlockRenderView;

public class SanixFMClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		ScreenProviderRegistry.INSTANCE.registerFactory(SkyDiamondHelmet.ID, (syncId, id, player, buf) -> new SkyDiamondHelmetScreen(new SkyDiamondHelmetController(syncId, player.inventory), player));
		setupFluidRendering(SanixFM.LIME_WATER_STILL, SanixFM.LIME_WATER_FLOWING, new Identifier("sanixfm", "lime_water"));
		BlockRenderLayerMap.INSTANCE.putFluids(RenderLayer.getTranslucent(), SanixFM.LIME_WATER_STILL, SanixFM.LIME_WATER_FLOWING);
	}

	public static void setupFluidRendering(BaseFluid fluidstill, BaseFluid fluidflowing, final Identifier texturefluidID) {
		
		final Identifier stillSpriteID = new Identifier(texturefluidID.getNamespace(), "block/" + texturefluidID.getPath() + "_still");
		final Identifier flowingSpriteID = new Identifier(texturefluidID.getNamespace(), "block/" + texturefluidID.getPath() + "_flow");
		
		ClientSpriteRegistryCallback.event(SpriteAtlasTexture.BLOCK_ATLAS_TEX).register((atlasTexture, registry) -> {
			registry.register(stillSpriteID);
			registry.register(flowingSpriteID);
		});
		
		final Identifier fluidID = Registry.FLUID.getId(fluidstill);
		final Identifier listenerID = new Identifier(fluidID.getNamespace(), fluidID.getPath() + "_reload_listener");
		
		final Sprite[] fluidSprites = new Sprite[] {null, null};
		
		ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(new SimpleSynchronousResourceReloadListener() {

			@Override
			public Identifier getFabricId() {
				return listenerID;
			}

			@Override
			public void apply(ResourceManager manager) {
				final Function<Identifier, Sprite> atlas = MinecraftClient.getInstance().getSpriteAtlas(SpriteAtlasTexture.BLOCK_ATLAS_TEX);
				fluidSprites[0] = atlas.apply(stillSpriteID);
				fluidSprites[1] = atlas.apply(flowingSpriteID);
			}
			
		});
		
		final FluidRenderHandler renderHandler = new FluidRenderHandler() {

			@Override
			public Sprite[] getFluidSprites(BlockRenderView view, BlockPos pos, FluidState state) {
				return fluidSprites;
			}
			
		};
		
		FluidRenderHandlerRegistry.INSTANCE.register(fluidstill, renderHandler);
		FluidRenderHandlerRegistry.INSTANCE.register(fluidflowing, renderHandler);
		
	}

}
