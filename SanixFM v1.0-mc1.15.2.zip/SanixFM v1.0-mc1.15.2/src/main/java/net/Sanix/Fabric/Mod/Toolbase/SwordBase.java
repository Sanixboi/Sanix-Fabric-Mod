package net.Sanix.Fabric.Mod.Toolbase;

import net.Sanix.Fabric.Mod.SanixFM;
import net.minecraft.item.Item;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;

public class SwordBase extends SwordItem {

	public SwordBase(ToolMaterial material, int attackDamage, float attackSpeed) {
		super(material, attackDamage, attackSpeed, new Item.Settings().group(SanixFM.TOOLS));
	}

}
