package net.Sanix.Fabric.Mod.toolmaterial;

import net.minecraft.block.Blocks;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class ToolMaterialDarkOak implements ToolMaterial{

	@Override
	public int getDurability() {
		return 70;
	}

	@Override
	public float getMiningSpeed() {
		return 2;
	}

	@Override
	public float getAttackDamage() {
		return 0.0f;
	}

	@Override
	public int getMiningLevel() {
		return 0;
	}

	@Override
	public int getEnchantability() {
		return 16;
	}

	@Override
	public Ingredient getRepairIngredient() {
		return Ingredient.ofItems(Blocks.DARK_OAK_PLANKS);
	}

}
