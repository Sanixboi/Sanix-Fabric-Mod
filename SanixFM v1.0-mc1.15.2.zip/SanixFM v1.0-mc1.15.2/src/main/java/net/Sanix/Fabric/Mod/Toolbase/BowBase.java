package net.Sanix.Fabric.Mod.Toolbase;

import net.Sanix.Fabric.Mod.SanixFM;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;

public class BowBase extends BowItem {

	public BowBase() {
		super(new Item.Settings().maxDamage(2000).group(SanixFM.TOOLS));
	}

}
