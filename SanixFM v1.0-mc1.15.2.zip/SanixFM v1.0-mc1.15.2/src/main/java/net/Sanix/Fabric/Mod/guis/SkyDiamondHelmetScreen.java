package net.Sanix.Fabric.Mod.guis;

import io.github.cottonmc.cotton.gui.client.CottonInventoryScreen;
import net.Sanix.Fabric.Mod.inventories.SkyDiamondHelmetController;
import net.minecraft.entity.player.PlayerEntity;

public class SkyDiamondHelmetScreen extends CottonInventoryScreen<SkyDiamondHelmetController> {

	public SkyDiamondHelmetScreen(SkyDiamondHelmetController container, PlayerEntity player) {
		super(container, player);
	}

	
}

