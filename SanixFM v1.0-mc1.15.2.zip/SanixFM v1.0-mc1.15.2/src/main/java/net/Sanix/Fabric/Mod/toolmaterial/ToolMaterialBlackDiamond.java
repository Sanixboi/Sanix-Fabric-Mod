package net.Sanix.Fabric.Mod.toolmaterial;

import net.Sanix.Fabric.Mod.SanixFM;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class ToolMaterialBlackDiamond implements ToolMaterial{

	@Override
	public int getDurability() {
		return 2000;
	}

	@Override
	public float getMiningSpeed() {
		return 12;
	}

	@Override
	public float getAttackDamage() {
		return 3.5f;
	}

	@Override
	public int getMiningLevel() {
		return 3;
	}

	@Override
	public int getEnchantability() {
		return 20;
	}

	@Override
	public Ingredient getRepairIngredient() {
		return Ingredient.ofItems(SanixFM.BLACK_DIAMOND);
	}

}
