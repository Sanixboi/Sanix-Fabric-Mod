package net.Sanix.Fabric.Mod.blocks;

import net.fabricmc.fabric.api.block.FabricBlockSettings;
import net.fabricmc.fabric.api.tools.FabricToolTags;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.sound.BlockSoundGroup;

public class EnderPearlReinforcedDiamondBlock extends Block {
	
	public EnderPearlReinforcedDiamondBlock() {
		super(FabricBlockSettings.of(Material.METAL).breakByHand(false).breakByTool(FabricToolTags.PICKAXES, 3).sounds(BlockSoundGroup.METAL).hardness(10f).resistance(9.2512f).build());
	}
	

}
