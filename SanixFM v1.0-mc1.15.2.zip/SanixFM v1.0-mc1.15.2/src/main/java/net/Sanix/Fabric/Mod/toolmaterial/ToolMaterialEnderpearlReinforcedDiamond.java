package net.Sanix.Fabric.Mod.toolmaterial;

import net.Sanix.Fabric.Mod.SanixFM;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class ToolMaterialEnderpearlReinforcedDiamond implements ToolMaterial{

	@Override
	public int getDurability() {
		return 6720;
	}

	@Override
	public float getMiningSpeed() {
		return 42;
	}

	@Override
	public float getAttackDamage() {
		return 7.0f;
	}

	@Override
	public int getMiningLevel() {
		return 4;
	}

	@Override
	public int getEnchantability() {
		return 45;
	}

	@Override
	public Ingredient getRepairIngredient() {
		return Ingredient.ofItems(SanixFM.ENDER_PEARL_REINFORCED_DIAMOND_BLOCK); 
	}

}
