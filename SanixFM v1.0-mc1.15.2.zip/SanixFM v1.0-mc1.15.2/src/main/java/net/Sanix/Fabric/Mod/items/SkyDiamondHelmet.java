package net.Sanix.Fabric.Mod.items;

import net.Sanix.Fabric.Mod.SanixFM;
import net.Sanix.Fabric.Mod.ArmorMaterial.ModdedArmorMaterials;
import net.Sanix.Fabric.Mod.guis.SkyDiamondHelmetScreen;
import net.Sanix.Fabric.Mod.inventories.SkyDiamondHelmetController;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class SkyDiamondHelmet extends ArmorItem {

	public static final Identifier ID = new Identifier(SanixFM.MODID, "sky_diamond_helmet");

	public SkyDiamondHelmet() {
		super(ModdedArmorMaterials.SKY_DIAMOND, EquipmentSlot.HEAD, new Item.Settings().group(SanixFM.ARMOR));
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		MinecraftClient.getInstance().openScreen(new SkyDiamondHelmetScreen(new SkyDiamondHelmetController(protection, user.inventory), user));
		return super.use(world, user, hand);
	}
}
