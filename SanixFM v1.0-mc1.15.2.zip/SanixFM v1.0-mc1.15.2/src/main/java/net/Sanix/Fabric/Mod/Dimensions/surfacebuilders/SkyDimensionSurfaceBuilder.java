package net.Sanix.Fabric.Mod.Dimensions.surfacebuilders;

import java.util.Random;
import java.util.function.Function;

import com.mojang.datafixers.Dynamic;

import net.minecraft.block.BlockState;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.gen.surfacebuilder.SurfaceBuilder;
import net.minecraft.world.gen.surfacebuilder.SurfaceConfig;

public class SkyDimensionSurfaceBuilder extends SurfaceBuilder<SurfaceConfig>{

	public SkyDimensionSurfaceBuilder(Function<Dynamic<?>, ? extends SurfaceConfig> function) {
		super(function);
	}

	@Override
	public void generate(Random random, Chunk chunk, Biome biome, int x, int z, int height, double noise,
			BlockState defaultBlock, BlockState defaultFluid, int seaLevel, long seed, SurfaceConfig surfaceBlocks) {		
	}

}
