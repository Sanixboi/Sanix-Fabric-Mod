package net.Sanix.Fabric.Mod.Dimensions;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.dimension.Dimension;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.gen.chunk.ChunkGenerator;

public class SkyDimension extends Dimension {

	public SkyDimension(World world, DimensionType type, float f) {
		super(world, type, f);
	}

	@Override
	public ChunkGenerator<?> createChunkGenerator() {
		return createChunkGenerator();
	}

	@Override
	public BlockPos getSpawningBlockInChunk(ChunkPos chunkPos, boolean checkMobSpawnValidity) {
		return null;
	}

	@Override
	public BlockPos getTopSpawningBlockPosition(int x, int z, boolean checkMobSpawnValidity) {
		return BlockPos.ORIGIN;
	}

	@Override
	public float getSkyAngle(long timeOfDay, float tickDelta) {
		return 0;
	}

	@Override
	public boolean hasVisibleSky() {
		return true;
	}

	@Override
	public Vec3d getFogColor(float skyAngle, float tickDelta) {
		return null;
	}

	@Override
	public boolean canPlayersSleep() {
		return true;
	}

	@Override
	public boolean isFogThick(int x, int z) {
		return false;
	}

	@Override
	public DimensionType getType() {
		return DimensionType.THE_END;
	}

}
