package net.Sanix.Fabric.Mod.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.Sanix.Fabric.Mod.SanixFM;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.world.World;
import net.minecraft.world.dimension.DimensionType;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin extends LivingEntity {


	public PlayerEntityMixin(EntityType<? extends LivingEntity> type, World world) {
		super(type, world);
	}

	
	@Inject(at = @At("HEAD"), method = "tick")
	private void tick(CallbackInfo info) throws InterruptedException {
		ItemStack holdingItemStack = getMainHandStack();
		ItemStack hs = this.getEquippedStack(EquipmentSlot.HEAD);
		ItemStack cs = this.getEquippedStack(EquipmentSlot.CHEST);
		ItemStack ls = this.getEquippedStack(EquipmentSlot.LEGS);
		ItemStack bootss = this.getEquippedStack(EquipmentSlot.FEET);
		if (holdingItemStack.getItem().equals(SanixFM.SKY_DIAMOND_SWORD)) {
			if(hs.getItem().equals(SanixFM.SKY_DIAMOND_HELMET)) {
				if (cs.getItem().equals(SanixFM.SKY_DIAMOND_CHESTPLATE) || cs.getItem().equals(Items.ELYTRA)) {
					if (ls.getItem().equals(SanixFM.SKY_DIAMOND_LEGGINGS) && bootss.getItem().equals(SanixFM.SKY_DIAMOND_BOOTS)) {
						    if (getAbsorptionAmount() == 10 ) {
						    	StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.STRENGTH, 100, 2);
						        addStatusEffect(effect);
						    }
							StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.STRENGTH, 100, 1);
					        addStatusEffect(effect);		        
					} else {
						StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.STRENGTH, 100);
						addStatusEffect(effect);
					}
				} else {
					StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.STRENGTH, 100);
					 addStatusEffect(effect);
				}
				
			 } else {
				 StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.STRENGTH, 100);
				 addStatusEffect(effect);
			 }
		}
		
		if (holdingItemStack.getItem().equals(SanixFM.SKY_DIAMOND_PICKAXE)) {
			if(hs.getItem().equals(SanixFM.SKY_DIAMOND_HELMET)) {
				if (cs.getItem().equals(SanixFM.SKY_DIAMOND_CHESTPLATE) || cs.getItem().equals(Items.ELYTRA)) {
					if (ls.getItem().equals(SanixFM.SKY_DIAMOND_LEGGINGS) && bootss.getItem().equals(SanixFM.SKY_DIAMOND_BOOTS)) {
							StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.HASTE, 100, 2);
					        addStatusEffect(effect);		        
					} else {
						StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.HASTE, 100, 1);
						addStatusEffect(effect);
					}
				} else {
					StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.HASTE, 100, 1);
					 addStatusEffect(effect);
				}
				
			 } else {
				 StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.HASTE, 100, 1);
				 addStatusEffect(effect);
			 }
		}
		
		if (holdingItemStack.getItem().equals(SanixFM.SKY_DIAMOND_AXE)) {
			if(hs.getItem().equals(SanixFM.SKY_DIAMOND_HELMET)) {
				if (cs.getItem().equals(SanixFM.SKY_DIAMOND_CHESTPLATE) || cs.getItem().equals(Items.ELYTRA)) {
					if (ls.getItem().equals(SanixFM.SKY_DIAMOND_LEGGINGS) && bootss.getItem().equals(SanixFM.SKY_DIAMOND_BOOTS)) {
							StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.HASTE, 100, 2);
					        addStatusEffect(effect);		        
					} else {
						StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.HASTE, 100, 1);
						addStatusEffect(effect);
					}
				} else {
					StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.HASTE, 100, 1);
					 addStatusEffect(effect);
				}
				
			 } else {
				 StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.HASTE, 100, 1);
				 addStatusEffect(effect);
			 }
		}
		
		if (holdingItemStack.getItem().equals(SanixFM.SKY_DIAMOND_SHOVEL)) {
			if(hs.getItem().equals(SanixFM.SKY_DIAMOND_HELMET)) {
				if (cs.getItem().equals(SanixFM.SKY_DIAMOND_CHESTPLATE) || cs.getItem().equals(Items.ELYTRA)) {
					if (ls.getItem().equals(SanixFM.SKY_DIAMOND_LEGGINGS) && bootss.getItem().equals(SanixFM.SKY_DIAMOND_BOOTS)) {
							StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.HASTE, 100, 2);
					        addStatusEffect(effect);		        
					} else {
						StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.HASTE, 100, 1);
						addStatusEffect(effect);
					}
				} else {
					StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.HASTE, 100, 1);
					 addStatusEffect(effect);
				}
				
			 } else {
				 StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.HASTE, 100, 1);
				 addStatusEffect(effect);
			 }
		}
	
	if(dimension.equals(DimensionType.THE_NETHER)) {
		ItemStack helmetStack = this.getEquippedStack(EquipmentSlot.HEAD);
		ItemStack chestplateStack = this.getEquippedStack(EquipmentSlot.CHEST);
		ItemStack leggingsStack = this.getEquippedStack(EquipmentSlot.LEGS);
		ItemStack bootsStack = this.getEquippedStack(EquipmentSlot.FEET);
		
		if(helmetStack.getItem().equals(SanixFM.SKY_DIAMOND_HELMET)) {
			if (chestplateStack.getItem().equals(SanixFM.SKY_DIAMOND_CHESTPLATE) || chestplateStack.getItem().equals(Items.ELYTRA)) {
				if (leggingsStack.getItem().equals(SanixFM.SKY_DIAMOND_LEGGINGS) && bootsStack.getItem().equals(SanixFM.SKY_DIAMOND_BOOTS)) {
					StatusEffectInstance effect2 = new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 5 * 20);
					addStatusEffect(effect2);
				}
			}
			
		 }
	}
	
	if (isBlocking() == true) {
		   ItemStack helmetStack = this.getEquippedStack(EquipmentSlot.HEAD);
		   ItemStack chestplateStack = this.getEquippedStack(EquipmentSlot.CHEST);
		   ItemStack leggingsStack = this.getEquippedStack(EquipmentSlot.LEGS);
		   ItemStack bootsStack = this.getEquippedStack(EquipmentSlot.FEET);
	
		   int resistancelvl = 0;
		   if(helmetStack.getItem().equals(SanixFM.SKY_DIAMOND_HELMET)) {
			   if (resistancelvl < 4) {
				   resistancelvl++;
			   }
		   }
		   
		   if(chestplateStack.getItem().equals(SanixFM.SKY_DIAMOND_CHESTPLATE)) {
			   if (resistancelvl < 4) {
				   resistancelvl++;
			   }
		   }
		   
		   if(leggingsStack.getItem().equals(SanixFM.SKY_DIAMOND_LEGGINGS)) {
			   if (resistancelvl < 4) {
				   resistancelvl++;
			   }
		   }
		   
		   if(bootsStack.getItem().equals(SanixFM.SKY_DIAMOND_BOOTS)) {
			   if (resistancelvl < 4) {
				   resistancelvl++;
			   }
		   }
		   
		   if (resistancelvl > 0) {
			   StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.RESISTANCE, 100, resistancelvl - 1);
			   addStatusEffect(effect);
			   
		   }
		   
	}
	
	
	if(isSprinting() == true) {
		ItemStack helmetStack = this.getEquippedStack(EquipmentSlot.HEAD);
		ItemStack chestplateStack = this.getEquippedStack(EquipmentSlot.CHEST);
		ItemStack leggingsStack = this.getEquippedStack(EquipmentSlot.LEGS);
		ItemStack bootsStack = this.getEquippedStack(EquipmentSlot.FEET);
		
		int speedlvl = 0;
		   if(helmetStack.getItem().equals(SanixFM.SKY_DIAMOND_HELMET) && chestplateStack.getItem().equals(SanixFM.SKY_DIAMOND_CHESTPLATE)) {
			   if (speedlvl < 2) {
				   speedlvl++;
			   }
		   }
		   
		   if(leggingsStack.getItem().equals(SanixFM.SKY_DIAMOND_LEGGINGS) && bootsStack.getItem().equals(SanixFM.SKY_DIAMOND_BOOTS)) {
			   if (speedlvl < 2) {
				   speedlvl++;
			   }
		   }
		   
		if (speedlvl > 0) {
			   StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.SPEED, 100, speedlvl - 1);
			   addStatusEffect(effect);
		  }
	}
	
	if (isInSwimmingPose() == true) {
		ItemStack helmetStack = this.getEquippedStack(EquipmentSlot.HEAD);
		ItemStack leggingsStack = this.getEquippedStack(EquipmentSlot.LEGS);
		ItemStack bootsStack = this.getEquippedStack(EquipmentSlot.FEET);
		if(helmetStack.getItem().equals(SanixFM.SKY_DIAMOND_HELMET) && leggingsStack.getItem().equals(SanixFM.SKY_DIAMOND_LEGGINGS) && bootsStack.getItem().equals(SanixFM.SKY_DIAMOND_BOOTS)) {
			StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.DOLPHINS_GRACE, 5 * 20, 1);
			addStatusEffect(effect);
		 }
	}
	
	if(isDescending() == true) {
		ItemStack helmetStack = this.getEquippedStack(EquipmentSlot.HEAD);
		ItemStack chestplateStack = this.getEquippedStack(EquipmentSlot.CHEST);
		ItemStack leggingsStack = this.getEquippedStack(EquipmentSlot.LEGS);
		ItemStack bootsStack = this.getEquippedStack(EquipmentSlot.FEET);
		if(helmetStack.getItem().equals(SanixFM.SKY_DIAMOND_HELMET)) {
			if (chestplateStack.getItem().equals(SanixFM.SKY_DIAMOND_CHESTPLATE) || chestplateStack.getItem().equals(Items.ELYTRA)) {
				if (leggingsStack.getItem().equals(SanixFM.SKY_DIAMOND_LEGGINGS) && bootsStack.getItem().equals(SanixFM.SKY_DIAMOND_BOOTS)) {
					StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.SLOW_FALLING, 5 * 20);
			        addStatusEffect(effect);
				}
			}
			
			
		 }
	}
	
	if (isHandSwinging == true) {
		ItemStack helmetStack = this.getEquippedStack(EquipmentSlot.HEAD);
		ItemStack chestplateStack = this.getEquippedStack(EquipmentSlot.CHEST);
		ItemStack leggingsStack = this.getEquippedStack(EquipmentSlot.LEGS);
		ItemStack bootsStack = this.getEquippedStack(EquipmentSlot.FEET);
		if(helmetStack.getItem().equals(SanixFM.SKY_DIAMOND_HELMET)) {
			if (chestplateStack.getItem().equals(SanixFM.SKY_DIAMOND_CHESTPLATE) || chestplateStack.getItem().equals(Items.ELYTRA)) {
				if (leggingsStack.getItem().equals(SanixFM.SKY_DIAMOND_LEGGINGS) && bootsStack.getItem().equals(SanixFM.SKY_DIAMOND_BOOTS)) {
					StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.HASTE, 5 * 20, 1);
					addStatusEffect(effect);
				}
			}
		 }
	}
	
	ItemStack helmetStack = this.getEquippedStack(EquipmentSlot.HEAD);
	ItemStack chestplateStack = this.getEquippedStack(EquipmentSlot.CHEST);
	ItemStack leggingsStack = this.getEquippedStack(EquipmentSlot.LEGS);
	ItemStack bootsStack = this.getEquippedStack(EquipmentSlot.FEET);
	if(helmetStack.getItem().equals(SanixFM.SKY_DIAMOND_HELMET)) {
		if (chestplateStack.getItem().equals(SanixFM.SKY_DIAMOND_CHESTPLATE) || chestplateStack.getItem().equals(Items.ELYTRA)) {
			if (leggingsStack.getItem().equals(SanixFM.SKY_DIAMOND_LEGGINGS) && bootsStack.getItem().equals(SanixFM.SKY_DIAMOND_BOOTS)) {
				if (!(getHealth() <= 10)) {
					StatusEffectInstance effect = new StatusEffectInstance(StatusEffects.SATURATION, 1 * 20);
					addStatusEffect(effect);
				}
				StatusEffectInstance effect2 = new StatusEffectInstance(StatusEffects.NIGHT_VISION, 30 * 20);
				addStatusEffect(effect2);
			}
		}
		
	 }
	
	}
  }

