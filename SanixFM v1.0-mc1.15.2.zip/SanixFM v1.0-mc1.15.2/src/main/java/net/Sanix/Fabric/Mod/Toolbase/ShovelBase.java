package net.Sanix.Fabric.Mod.Toolbase;

import net.Sanix.Fabric.Mod.SanixFM;
import net.minecraft.item.Item;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.ToolMaterial;

public class ShovelBase extends ShovelItem {

	public ShovelBase(ToolMaterial material, float attackDamage, float attackSpeed) {
		super(material, attackDamage, attackSpeed, new Item.Settings().group(SanixFM.TOOLS));
	}

}
