package net.Sanix.Fabric.Mod.inventories;


import io.github.cottonmc.cotton.gui.CottonCraftingController;
import io.github.cottonmc.cotton.gui.widget.WGridPanel;
import io.github.cottonmc.cotton.gui.widget.WItemSlot;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.recipe.RecipeType;

public class SkyDiamondHelmetController extends CottonCraftingController {

	public SkyDiamondHelmetController(int syncId, PlayerInventory playerInventory) {
		super(RecipeType.SMELTING, syncId, playerInventory);
		
		WGridPanel root = new WGridPanel();
		setRootPanel(root);
		root.setSize(150, 100);
		WItemSlot inventory = WItemSlot.of(SkyDiamondHelmetInv.ofSize(3), 0, 3, 1);
		root.add(inventory, 4, 1);
		
		root.add(this.createPlayerInventoryPanel(), 0, 3);
		
		root.validate(this);
	}


}
