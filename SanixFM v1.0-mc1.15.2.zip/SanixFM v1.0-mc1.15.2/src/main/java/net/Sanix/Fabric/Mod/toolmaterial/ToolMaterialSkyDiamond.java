package net.Sanix.Fabric.Mod.toolmaterial;

import net.Sanix.Fabric.Mod.SanixFM;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class ToolMaterialSkyDiamond implements ToolMaterial{

	@Override
	public int getDurability() {
		return 10920;
	}

	@Override
	public float getMiningSpeed() {
		return 62;
	}

	@Override
	public float getAttackDamage() {
		return 8.5f;
	}

	@Override
	public int getMiningLevel() {
		return 5;
	}

	@Override
	public int getEnchantability() {
		return 55;
	}

	@Override
	public Ingredient getRepairIngredient() {
		return Ingredient.ofItems(SanixFM.SKY_DIAMOND_BLOCK); 
	}

}
