package net.Sanix.Fabric.Mod.toolmaterial;

import net.Sanix.Fabric.Mod.SanixFM;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class ToolMaterialEmeraldReinforcedDiamond implements ToolMaterial{

	@Override
	public int getDurability() {
		return 4096;
	}

	@Override
	public float getMiningSpeed() {
		return 30;
	}

	@Override
	public float getAttackDamage() {
		return 5f;
	}

	@Override
	public int getMiningLevel() {
		return 3;
	}

	@Override
	public int getEnchantability() {
		return 33;
	}

	@Override
	public Ingredient getRepairIngredient() {
		return Ingredient.ofItems(SanixFM.EMERALD_REINFORCED_DIAMOND); 
	}

}
