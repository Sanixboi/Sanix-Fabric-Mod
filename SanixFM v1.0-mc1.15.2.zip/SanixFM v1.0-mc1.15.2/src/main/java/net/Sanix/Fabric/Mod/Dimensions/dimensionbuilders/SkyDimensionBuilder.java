package net.Sanix.Fabric.Mod.Dimensions.dimensionbuilders;

import java.util.List;
import java.util.function.BiFunction;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.map.MapState;
import net.minecraft.recipe.RecipeManager;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.tag.RegistryTagManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.profiler.Profiler;
import net.minecraft.world.TickScheduler;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.ChunkManager;
import net.minecraft.world.dimension.Dimension;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.level.LevelProperties;

public class SkyDimensionBuilder extends World {

	public SkyDimensionBuilder(LevelProperties levelProperties, DimensionType dimensionType, BiFunction<World, Dimension, ChunkManager> chunkManagerProvider, Profiler profiler, boolean isClient) {
		super(levelProperties, dimensionType, chunkManagerProvider, profiler, isClient);
	}

	
	public TickScheduler<Block> getBlockTickScheduler() {
		return null;
	}

	
	public TickScheduler<Fluid> getFluidTickScheduler() {
		return null;
	}

	
	public void playLevelEvent(PlayerEntity player, int eventId, BlockPos blockPos, int data) {
		
	}

	
	public List<? extends PlayerEntity> getPlayers() {
		return null;
	}

	
	public Biome getGeneratorStoredBiome(int biomeX, int biomeY, int biomeZ) {
		return null;

	}

	
	public void updateListeners(BlockPos pos, BlockState oldState, BlockState newState, int flags) {
		
	}

	
	public void playSound(PlayerEntity player, double x, double y, double z, SoundEvent sound, SoundCategory category,
			float volume, float pitch) {
		
	}

	
	public void playSoundFromEntity(PlayerEntity playerEntity, Entity entity, SoundEvent soundEvent,
			SoundCategory soundCategory, float volume, float pitch) {
		
	}

	@Override
	public Entity getEntityById(int id) {
		return null;
	}

	@Override
	public MapState getMapState(String id) {
		return null;
	}

	@Override
	public void putMapState(MapState mapState) {
		
	}

	@Override
	public int getNextMapId() {
		return 0;
	}

	@Override
	public void setBlockBreakingInfo(int entityId, BlockPos pos, int progress) {
		
	}

	@Override
	public Scoreboard getScoreboard() {
		return null;
	}

	@Override
	public RecipeManager getRecipeManager() {
		return null;
	}

	@Override
	public RegistryTagManager getTagManager() {
		return null;
	}

}
