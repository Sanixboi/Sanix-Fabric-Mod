package net.Sanix.Fabric.Mod.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ConfirmChatLinkScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.resourcepack.ResourcePackOptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.AbstractButtonWidget;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

@Mixin(TitleScreen.class)
public class TitleScreenMixin extends Screen {

	protected TitleScreenMixin(Text title) {
		super(title);
	}
	
	
	@Overwrite 
	private void initWidgetsNormal (int y, int spacingY) {
		this.addButton(new ButtonWidget(this.width / 2 - 100, y, 200, 20, I18n.translate("menu.singleplayer"), (buttonWidget) -> {
	         this.minecraft.openScreen(new SelectWorldScreen(this));
	      }));
	      this.addButton(new ButtonWidget(this.width / 2 - 100, y + spacingY * 1, 200, 20, I18n.translate("menu.multiplayer"), (buttonWidget) -> {
	            this.minecraft.openScreen(new MultiplayerScreen(this));
	      }));
		
		this.addButton(new ButtonWidget(this.width / 2 - 100, this.height / 4 + 48 + 24 * 2, 98, 20, "Resource Packs", (buttonWidget) -> {
	         MinecraftClient.getInstance().openScreen(new ResourcePackOptionsScreen(this, this.minecraft.options));
	     }));
		 String string = "https://www.youtube.com/channel/UC8ei-X0EuRI1iGCl2k4x4_Q";
	     this.addButton(new ButtonWidget(this.width / 2 + 2, this.height / 4 + 48 + 24 * 2, 98, 20, "Sub 2 Sanixboi", (buttonWidgetx) -> {
	         this.minecraft.openScreen(new ConfirmChatLinkScreen((bl) -> {
	            if (bl) {
	               Util.getOperatingSystem().open(string);
	            }

	            this.minecraft.openScreen(this);
	         }, string, true));
	      }));
	}
	
	protected <T extends AbstractButtonWidget> T addButton(T button) {
		if (button.y <= this.height / 4 + 48 + 24 * 3) {
			button.y -= 12;
		}
		if (button.y > this.height / 4 + 48 + 24 * 3) {
			button.y += 12;
		}
		return super.addButton(button);
	}
}